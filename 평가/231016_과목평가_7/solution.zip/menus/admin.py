from django.contrib import admin

# 문제 05. Admin page에 Menu 등록하기
# Todo : Menus 앱의 Menu 모델을 Admin 페이지에서 수정할 수 있도록 등록 필요
from .models import Menu


admin.site.register(Menu)